package cf8.curso.java.tp1.entitides;

public class AutoNuevo extends Vehiculo {

    public AutoNuevo(String color, String marca, String modelo, double precio, String marcaRadio, String modeloRadio) {
        super(color, marca, modelo, precio);
        super.setRadioDatosCompleto(marcaRadio, modeloRadio);
    }

    public AutoNuevo(String color, String marca, String modelo, Radio radio) {
        super(color, marca, modelo, radio);
    }

}
