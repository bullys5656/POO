package cf8.curso.java.tp1.test;

import cf8.curso.java.tp1.entitides.AutoNuevo;
import cf8.curso.java.tp1.entitides.Radio;

public class AutoNuevoTest {
    
    public static void main(String[] args) {
        
        AutoNuevo autoN1 = new AutoNuevo("Amarillo", "Chevrolet", "Zafira", 4500000, "Pioneer", "XXYY00");
        System.out.println(autoN1);
        
        Radio radioN1 = new Radio("YYXX00");
        AutoNuevo autoN2 = new AutoNuevo("Azul", "Ferrari", "F1", radioN1);
        System.out.println(autoN2);
        System.out.println("******************************************************************************************************");
        autoN2.setRadioMarca("Sanyo");
        autoN2.setRadioModelo("ALFA");
        System.out.println(autoN2);
        
    }
}
