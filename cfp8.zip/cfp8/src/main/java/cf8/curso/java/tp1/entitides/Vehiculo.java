package cf8.curso.java.tp1.entitides;

public abstract class Vehiculo {
    
    private String color;
    private String marca;
    private String modelo;
    private Radio radio;
    private double precio;
    
    public Vehiculo(String color, String marca, String modelo, Radio radio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.radio = radio;
    }
    
    public Vehiculo(String color, String marca, String modelo, double precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }
    
    public Vehiculo(String color, String marca, String modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    
    public String getMarca() {
        return marca;
    }
    
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public String getModelo() {
        return modelo;
    }
    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    public void setRadioDatosCompleto(String marcaRadio, String modeloRadio) {
        if (this.radio == null) {
            this.radio = new Radio(marcaRadio, modeloRadio);
        } else {
            this.radio.setMarcaRadio(marcaRadio);
            this.radio.setModeloRadio(modeloRadio);
        }
    }
    
    public void setRadioMarca(String marcaRadio) {
        if (this.radio == null) {
            this.radio = new Radio(marcaRadio);
        } else {
            this.radio.setMarcaRadio(marcaRadio);
        }
    }

    public void setRadioModelo(String modeloRadio) {
        
        this.radio.setModeloRadio(modeloRadio);
        
    }
    
    public double getPrecio() {
        return precio;
    }
    
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    @Override
    public String toString() {
        return "Vehiculo{" + "color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", radio=" + radio + ", precio=" + precio + '}';
    }
    
}
