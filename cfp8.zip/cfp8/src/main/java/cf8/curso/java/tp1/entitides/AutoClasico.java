package cf8.curso.java.tp1.entitides;

public class AutoClasico extends Vehiculo {

    public AutoClasico(String color, String marca, String modelo, double precio) {
        super(color, marca, modelo, precio);
    }

    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }

    public AutoClasico(String color, String marca, String modelo, String marcaRadio, String modeloRadio) {
        super(color, marca, modelo);
        super.setRadioDatosCompleto(marcaRadio, modeloRadio);
    }

    public AutoClasico(String color, String marca, String modelo, String marcaRadio) {
        super(color, marca, modelo);
        super.setRadioMarca(marcaRadio);
    }

    @Override
    public void setRadioDatosCompleto(String marcaRadio, String modeloRadio) {
        super.setRadioDatosCompleto(marcaRadio, modeloRadio);
    }

    @Override
    public void setRadioMarca(String marcaRadio) {
        super.setRadioMarca(marcaRadio);
    }

}
