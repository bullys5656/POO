package cf8.curso.java.tp1.test;

import cf8.curso.java.tp1.entitides.AutoClasico;
import java.util.ArrayList;
import java.util.List;

public class autoClasicoTest {

    public static void main(String[] args) {
        List<AutoClasico> listaAutoClasico = new ArrayList<AutoClasico>();
        AutoClasico autoC1 = new AutoClasico("Rojo", "Ford", "Escort");
        AutoClasico autoC2 = new AutoClasico("Azul", "Fiat", "Uno", "Sanyo");
        AutoClasico autoC3 = new AutoClasico("Rojo Furioso", "Renault", "Fuego", "Philips", "Con CD");
        autoC1.setRadioDatosCompleto("Sanyo", "123");
        AutoClasico autoC4 = new AutoClasico("Rojo", "Ford", "Escort");
        autoC1.setPrecio(2500);
        listaAutoClasico.add(autoC1);
        listaAutoClasico.add(autoC2);
        listaAutoClasico.add(autoC3);
        listaAutoClasico.add(autoC4);
        listaAutoClasico.forEach(o -> System.out.println(o));

    }

}
