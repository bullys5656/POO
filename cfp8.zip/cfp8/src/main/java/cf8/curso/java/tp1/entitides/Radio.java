package cf8.curso.java.tp1.entitides;

public class Radio {

    private String marcaRadio;
    private String modeloRadio;

    public Radio(String marcaRadio, String modeloRadio) {
        this.marcaRadio = marcaRadio;
        this.modeloRadio = modeloRadio;
    }

    public Radio(String marcaRadio) {
        this.marcaRadio = marcaRadio;
    }

    public String getMarcaRadio() {
        return marcaRadio;
    }

    public void setMarcaRadio(String marcaRadio) {
        this.marcaRadio = marcaRadio;
    }

    public String getModeloRadio() {
        return modeloRadio;
    }

    public void setModeloRadio(String modeloRadio) {
        this.modeloRadio = modeloRadio;
    }

    @Override
    public String toString() {
        return "Radio{" + "marcaRadio=" + marcaRadio + ", modeloRadio=" + modeloRadio + '}';
    }

}
