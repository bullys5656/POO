package cfp8.tpFinal.entities;

import cfp8.tpFinal.enums.EstadoRep;
import java.sql.Date;

public class Remito {

    private int id;
    private EstadoRep estado;
    private String falla;
    private String infoTec;
    private double precio;
    private Date fecha;
    private int id_cliente;
    private int id_equipo;
    private int id_repuesto;
    private int id_usuario;

    public Remito(int id, EstadoRep estado, String falla, String infoTec, double precio, Date fecha, int id_cliente, int id_equipo, int id_repuesto, int id_usuario) {
        this.id = id;
        this.estado = estado;
        this.falla = falla;
        this.infoTec = infoTec;
        this.precio = precio;
        this.fecha = fecha;
        this.id_cliente = id_cliente;
        this.id_equipo = id_equipo;
        this.id_repuesto = id_repuesto;
        this.id_usuario = id_usuario;
    }

    public Remito(EstadoRep estado, String falla, Date fecha, int id_cliente, int id_equipo, int id_usuario) {
        this.estado = estado;
        this.falla = falla;
        this.fecha = fecha;
        this.id_cliente = id_cliente;
        this.id_equipo = id_equipo;
        this.id_usuario = id_usuario;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public EstadoRep getEstado() {
        return estado;
    }

    public void setEstado(EstadoRep estado) {
        this.estado = estado;
    }

    public String getFalla() {
        return falla;
    }

    public void setFalla(String falla) {
        this.falla = falla;
    }

    public String getInfoTec() {
        return infoTec;
    }

    public void setInfoTec(String infoTec) {
        this.infoTec = infoTec;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getId_equipo() {
        return id_equipo;
    }

    public void setId_equipo(int id_equipo) {
        this.id_equipo = id_equipo;
    }

    public int getId_repuesto() {
        return id_repuesto;
    }

    public void setId_repuesto(int id_repuesto) {
        this.id_repuesto = id_repuesto;
    }

}
