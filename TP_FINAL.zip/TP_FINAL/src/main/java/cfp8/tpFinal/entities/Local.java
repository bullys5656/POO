
package cfp8.tpFinal.entities;

public class Local {
    
    private int id;
    private String direc;
    private String localidad;
    private String prov;
    private int altura;
    private int tel;
    private String comentarios;
    private String  mail;
    private String nomSuc;

    public Local(int id, String direc, String localidad, String prov, int altura, int tel, String comentarios, String mail, String nomSuc) {
        this.id = id;
        this.direc = direc;
        this.localidad = localidad;
        this.prov = prov;
        this.altura = altura;
        this.tel = tel;
        this.comentarios = comentarios;
        this.mail = mail;
        this.nomSuc = nomSuc;
    }

    public Local(String direc, String localidad, String prov, int altura, int tel, String nomSuc) {
        this.direc = direc;
        this.localidad = localidad;
        this.prov = prov;
        this.altura = altura;
        this.tel = tel;
        this.nomSuc = nomSuc;
    }

    public String getNomSuc() {
        return nomSuc;
    }

    public void setNomSuc(String nomSuc) {
        this.nomSuc = nomSuc;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDirec() {
        return direc;
    }

    public void setDirec(String direc) {
        this.direc = direc;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getProv() {
        return prov;
    }

    public void setProv(String prov) {
        this.prov = prov;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
    
    
    
}
