package cfp8.tpFinal.entities;

import cfp8.tpFinal.enums.TipoEquipo;

public class Equipo {

    private int id;
    private String marca;
    private String modelo;
    private String n_serie;
    private TipoEquipo tipoEquipo;
    private String comentarios;

    public Equipo(int id, String marca, String modelo, String n_serie, TipoEquipo tipoEquipo, String comentarios) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.n_serie = n_serie;
        this.tipoEquipo = tipoEquipo;
        this.comentarios = comentarios;
    }

    public Equipo(String marca, String modelo, String n_serie, TipoEquipo tipoEquipo, String comentarios) {
        this.marca = marca;
        this.modelo = modelo;
        this.n_serie = n_serie;
        this.tipoEquipo = tipoEquipo;
        this.comentarios = comentarios;
    }
   

    public Equipo() {
    }

    public int getId() {
        return id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getN_serie() {
        return n_serie;
    }

    public void setN_serie(String n_serie) {
        this.n_serie = n_serie;
    }

    public TipoEquipo getTipoEquipo() {
        return tipoEquipo;
    }

    public void setTipoEquipo(TipoEquipo tipoEquipo) {
        this.tipoEquipo = tipoEquipo;
    }

    public void setId(int id) {
        this.id = id;
    }

    

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    @Override
    public String toString() {
        return "Equipo{" + "id=" + id + ", marca=" + marca + ", modelo=" + modelo + ", n_serie=" + n_serie + ", tipoEquipo=" + tipoEquipo + ", comentarios=" + comentarios + '}';
    }
    

}
