
package cfp8.tpFinal.entities;

import cfp8.tpFinal.enums.TipoEquipo;

public class Equipo {
    private int id;
    private String marca;
    private String modelo;
    private String n_serie;
    private TipoEquipo tipoEquipo;

    public Equipo(int id, String marca, String modelo, String n_serie, TipoEquipo tipoEquipo) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.n_serie = n_serie;
        this.tipoEquipo = tipoEquipo;
    }

    public Equipo(String marca, String modelo, String n_serie, TipoEquipo tipoEquipo) {
        this.marca = marca;
        this.modelo = modelo;
        this.n_serie = n_serie;
        this.tipoEquipo = tipoEquipo;
    }

    public Equipo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public TipoEquipo getTipoEquipo() {
        return tipoEquipo;
    }

    public void setTipoEquipo(TipoEquipo tipoEquipo) {
        this.tipoEquipo = tipoEquipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getN_serie() {
        return n_serie;
    }

    public void setN_serie(String n_serie) {
        this.n_serie = n_serie;
    }
 
    
    
    
}
