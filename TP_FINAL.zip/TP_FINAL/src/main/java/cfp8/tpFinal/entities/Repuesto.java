
package cfp8.tpFinal.entities;

public class Repuesto {
    
}
