package cfp8.tpFinal.entities;

public class Repuesto {

    private int id;
    private String tipo;
    private String nSerie;
    private Double precio;
    private String marca;
    private String modelo, comentarios;

    public Repuesto(int id, String tipo, String nSerie, Double precio, String marca, String modelo, String comentarios) {
        this.id = id;
        this.tipo = tipo;
        this.nSerie = nSerie;
        this.precio = precio;
        this.marca = marca;
        this.modelo = modelo;
        this.comentarios = comentarios;
    }

    public Repuesto(String tipo, Double precio, String marca, String modelo) {
        this.tipo = tipo;
        this.precio = precio;
        this.marca = marca;
        this.modelo = modelo;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getnSerie() {
        return nSerie;
    }

    public void setnSerie(String nSerie) {
        this.nSerie = nSerie;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

}
