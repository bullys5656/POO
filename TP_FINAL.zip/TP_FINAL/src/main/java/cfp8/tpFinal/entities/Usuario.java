package cfp8.tpFinal.entities;

public class Usuario {

    private int id;
    private String nombre;
    private String appellido;
    private int tel;
    private String direccion;
    private String mail;
    private String comentarios;

    public Usuario(int id, String nombre, String appellido, int tel, String direccion, String mail, String comentarios) {
        this.id = id;
        this.nombre = nombre;
        this.appellido = appellido;
        this.tel = tel;
        this.direccion = direccion;
        this.mail = mail;
        this.comentarios = comentarios;
    }

    public Usuario(String nombre, String appellido, int tel, String direccion, String mail, String comentarios) {
        this.nombre = nombre;
        this.appellido = appellido;
        this.tel = tel;
        this.direccion = direccion;
        this.mail = mail;
        this.comentarios = comentarios;
    }

    public Usuario() {
    }

    public String getAppellido() {
        return appellido;
    }

    public void setAppellido(String appellido) {
        this.appellido = appellido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    @Override
    public String toString() {
        return "Usuario{" + "id=" + id + ", nombre=" + nombre + ", appellido=" + appellido + ", tel=" + tel + ", direccion=" + direccion + ", mail=" + mail + ", comentarios=" + comentarios + '}';
    }
    
    

}
