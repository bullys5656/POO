
-- use taller;
-- muestra todos los remitos con equipos ,clientes y usuario que lo recibio
select remitos.id as 'N°Remito', remitos.falla as FALLA, 
clientes.apellido as APELLIDO, clientes.nombre as NOMBRE, equipos.marca ,equipos.modelo,
usuarios.nombre, usuarios.apellido
from remitos inner join clientes on clientes.id= remitos.id_cliente
inner join equipos on equipos.id = remitos.id_equipo
inner join usuarios on usuarios.id= remitos.id_usuario;

-- Muestra los clientes con sus equipos

select clientes.apellido as Apellido, clientes.nombre as Nombre, equipos.marca as Marca, equipos.modelo as Modelo,
equipos.tipo, equipos.n_serie from remitos 
inner join clientes on clientes.id= remitos.id_cliente
inner join equipos on equipos.id= remitos.id_equipo;
-- Muestra los equipos recepcionados por el usuario tomas
select usuarios.apellido as Apellido, usuarios.nombre, equipos.marca as Marca, equipos.modelo as Modelo from remitos 
inner join usuarios on usuarios.id= remitos.id_usuario
inner join equipos on equipos.id = remitos.id_equipo
where nombre = 'tomas';

-- Muestra los clientes que comienza con 'G'
select * from clientes where  nombre like'g%';

-- Muestra equipos de la marca motorola
select equipos.marca,equipos.modelo,equipos.n_serie,equipos.tipo from remitos
inner join equipos on equipos.id = remitos.id_equipo
where equipos.marca like 'motorola';