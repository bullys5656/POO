
package cfp8.tpFinal.enums;

public enum TipoEquipo {
    CELULAR,
    TABLETA,
    DESKTOP,
    NOTEBOOK,
    CONSOLA,
    OTROS
}
