package cfp8.tpFinal.enums;

public enum EstadoRep {

    PRESUPUESTAR,
    REPARADO,
    SIN_REPARACION,
    ESPERANDO_CONFIRMACION,
    CONFIRMADO;
}
