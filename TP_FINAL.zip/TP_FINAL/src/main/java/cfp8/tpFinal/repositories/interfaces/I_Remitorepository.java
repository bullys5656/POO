package cfp8.tpFinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import cfp8.tpFinal.entities.Remito;

public interface I_Remitorepository {

    public void save(Remito remito);

    public void update(Remito remito);

    List<Remito> getAll();

    default Remito getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new Remito());
    }

  
}
