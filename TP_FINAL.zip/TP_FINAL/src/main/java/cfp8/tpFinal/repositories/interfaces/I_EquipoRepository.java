package cfp8.tpFinal.repositories.interfaces;



import cfp8.tpFinal.entities.Equipo;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public interface I_EquipoRepository {
    
     public void save(Equipo equipo);

    public void update(Equipo equipo);

    List<Equipo> getAll();

    default Equipo getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new Equipo());
    }


     default List<Equipo> getNSerie(String nSerie) {
        if (nSerie == null) {
            return new ArrayList();
        }
        return getAll()
                .stream()
                .filter(
                        a -> a.getN_serie()!= null
                        && a.getN_serie().toLowerCase().contains(nSerie.toLowerCase()))
                .collect(Collectors.toList());
    }

    
    
    
}
