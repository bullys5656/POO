
package cfp8.tpFinal.repositories.interfaces;

import cfp8.tpFinal.entities.Cliente;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public interface I_ClienteRepository {

    public void save(Cliente cliente);

    public void update(Cliente cliente);

    List<Cliente> getAll();

    default Cliente getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new Cliente());
    }

    default List<Cliente> getLikeNombre(String nombre) {
        if (nombre == null) {
            return new ArrayList();
        }
        return getAll()
                .stream()
                .filter(
                        n -> n.getNombre() != null
                        && n.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }

    default List<Cliente> getLikeApellido(String apellido) {
        if (apellido == null) {
            return new ArrayList();
        }
        return getAll()
                .stream()
                .filter(
                        a -> a.getApellido() != null
                        && a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
    
 
    

}
