package cfp8.tpFinal.repositories.jdbc;

import cfp8.tpFinal.entities.Cliente;
import cfp8.tpFinal.repositories.interfaces.I_ClienteRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepositories implements I_ClienteRepository {

    private Connection conn;

    public ClienteRepositories(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Cliente cliente) {
        if (cliente == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into clientes (nombre,apellido,tel,mail,direccion,comentarios) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getApellido());
            ps.setInt(3, cliente.getTel());
            ps.setString(4, cliente.getMail());
            ps.setString(5, cliente.getDireccion());
            ps.setString(6, cliente.getComentarios());

            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                cliente.setId(rs.getInt(1));
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void update(Cliente cliente) {
        if (cliente == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement("update clientes set nombre=?, apellido=?, tel=?, mail=?, direccion=?, comentarios=? " + "where id=?",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getApellido());
            ps.setInt(3, cliente.getTel());
            ps.setString(4, cliente.getMail());
            ps.setString(5, cliente.getDireccion());
            ps.setString(6, cliente.getComentarios());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
            //TODO agregar JOP
        }
    }

    @Override
    public List<Cliente> getAll() {
        List<Cliente> lst = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from clientes")) {
            while (rs.next()) {
                lst.add(new Cliente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("calle"),
                        rs.getInt("altura"),
                        rs.getString("telefono")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
            //TODO agregar aviso JOP
        }
        return lst;
    }
    
}
