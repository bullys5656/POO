package cfp8.tpFinal.repositories.jdbc;

import cfp8.tpFinal.entities.Repuesto;
import cfp8.tpFinal.repositories.interfaces.I_RepuestoRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class RepuestoRepositories implements I_RepuestoRepository {

    private Connection conn;

    public RepuestoRepositories(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Repuesto repuesto) {
        if (repuesto == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into repuestos (tipo,n_serie, marca,modelo,comentarios,precio) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, repuesto.getTipo());
            ps.setString(2, repuesto.getnSerie());
            ps.setString(3, repuesto.getMarca());
            ps.setString(4, repuesto.getModelo());
            ps.setString(5, repuesto.getComentarios());
            ps.setDouble(6, repuesto.getPrecio());

            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                repuesto.setId(rs.getInt(1));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Repuesto repuesto) {
        if (repuesto == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement("update repuestos set tipo=?, n_serie=?, marca=?, modelo=?,comentarios=?,precio=? " + "where id=?",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, repuesto.getTipo());
            ps.setString(2, repuesto.getnSerie());
            ps.setString(3, repuesto.getMarca());
            ps.setString(4, repuesto.getModelo());
            ps.setString(5, repuesto.getComentarios());
            ps.setDouble(6, repuesto.getPrecio());
            ps.setInt(7, repuesto.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
            //TODO agregar JOP
        }
    }

    @Override
    public List<Repuesto> getAll() {
        List<Repuesto> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from repuestos")) {
            while (rs.next()) {
                list.add(new Repuesto(rs.getInt("id"),
                        rs.getString("tipo"),
                        rs.getString("n_serie"),
                        rs.getDouble("precio"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getString("comentarios")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
}
