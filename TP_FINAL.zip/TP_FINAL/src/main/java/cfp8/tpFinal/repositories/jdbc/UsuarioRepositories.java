package cfp8.tpFinal.repositories.jdbc;

import cfp8.tpFinal.entities.Usuario;
import cfp8.tpFinal.repositories.interfaces.I_UsuarioRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UsuarioRepositories implements I_UsuarioRepository {

    private Connection conn;

    public UsuarioRepositories(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Usuario usuario) {
        if (usuario == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into usuarios (nombre,apellido,mail,direccion,tel,comentarios) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getAppellido());
            ps.setString(3, usuario.getMail());
            ps.setString(4, usuario.getDireccion());
            ps.setInt(5, usuario.getTel());
            ps.setString(6, usuario.getComentarios());

            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                usuario.setId(rs.getInt(1));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Usuario usuario) {
        if (usuario == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement("delete from usuarios where id=?")) {
            ps.setInt(1, usuario.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Usuario usuario) {
        if (usuario == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "update usuarios set nombre=?, apellido=?, mail=?, direccion=? tel=?, comentarios=? where id=?"
        )) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getAppellido());
            ps.setString(3, usuario.getMail());
            ps.setString(4, usuario.getDireccion());
            ps.setInt(5, usuario.getTel());
            ps.setString(6, usuario.getComentarios());
            ps.setInt(7, usuario.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Usuario> getAll() {
        List<Usuario> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from usuarios")) {
            while (rs.next()) {
                list.add(new Usuario(rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("tel"), rs.getString("direccion"),
                        rs.getString("mail"),
                        rs.getString("comentarios")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
}
