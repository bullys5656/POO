package cfp8.tpFinal.repositories.interfaces;

import cfp8.tpFinal.entities.Local;

import java.util.List;

public interface I_LocalRepository {

    public void save(Local local);

    public void update(Local local);

    public void remove(Local local);

    List<Local> getAll();

    default Local getById(int id) {
        return getAll()
                .stream()
                .filter(l -> l.getId() == id)
                .findFirst()
                .orElse(new Local());
    }

}
