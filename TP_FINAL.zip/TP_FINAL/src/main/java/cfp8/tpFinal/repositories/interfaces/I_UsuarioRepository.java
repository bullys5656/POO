package cfp8.tpFinal.repositories.interfaces;

import cfp8.tpFinal.entities.Usuario;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_UsuarioRepository {

    public void save(Usuario usuario);

    public void remove(Usuario usuario);

    public void update(Usuario usuario);

    List<Usuario> getAll();
    
        default List<Usuario> getLikeNombre(String nombre) {
        if (nombre == null) {
            return new ArrayList();
        }
        return getAll()
                .stream()
                .filter(
                        n -> n.getNombre() != null
                        && n.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    
default List<Usuario> getLikeApellido(String apellido) {
        if (apellido == null) {
            return new ArrayList();
        }
        return getAll()
                .stream()
                .filter(
                        a -> a.getAppellido()!= null
                        && a.getAppellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
}
