package cfp8.tpFinal.repositories.jdbc;

import cfp8.tpFinal.entities.Local;
import cfp8.tpFinal.repositories.interfaces.I_LocalRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;

public class LocalRepositories implements I_LocalRepository {

    private Connection conn;

    public LocalRepositories(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Local local) {
        if (local == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into locales (direccion,numeracion,localidad,provincia,nom_suc,tel,mail,comentarios) values (?,?,?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, local.getDirec());
            ps.setInt(2, local.getAltura());
            ps.setString(3, local.getLocalidad());
            ps.setString(4, local.getProv());
            ps.setString(5, local.getNomSuc());
            ps.setInt(6, local.getTel());
            ps.setString(7, local.getMail());
            ps.setString(8, local.getComentarios());

            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                local.setId(rs.getInt(1));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Local local) {
        if (local == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement("update locales set direccion=?,numeracion=?, localidad=?,provincia=?,nom_suc=?, tel=?,mail=?,comentarios=? " + "where id=?",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, local.getDirec());
            ps.setInt(2, local.getAltura());
            ps.setString(3, local.getLocalidad());
            ps.setString(4, local.getProv());
            ps.setString(5, local.getNomSuc());
            ps.setInt(6, local.getTel());
            ps.setString(7, local.getMail());
            ps.setString(8, local.getComentarios());
            ps.setInt(9, local.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
            //TODO agregar JOP
        }
    }

    @Override
    public void remove(Local local) {
        if (local == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement("delete from locales where id=?")) {
            ps.setInt(1, local.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Local> getAll() {
        List<Local> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from locales")) {
            while (rs.next()) {
                list.add(new Local(rs.getInt("id"),
                        rs.getString("direccion"),
                        rs.getString("localidad"),
                        rs.getString("provincia"),
                        rs.getInt("numeracion"),
                        rs.getInt("tel"),
                        rs.getString("comentarios"),
                        rs.getString("mail"),
                        rs.getString("nom_suc")
                ));

            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
}
