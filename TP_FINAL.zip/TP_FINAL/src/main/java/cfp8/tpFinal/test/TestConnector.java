package cfp8.tpFinal.test;

import cfp8.tpFinal.connectors.Connector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalDateTime;

public class TestConnector {

    public static void main(String[] args) {
        LocalDateTime ldtInicio = LocalDateTime.now();

        try ( Connection conn = new Connector().getConnection()) {
            ResultSet rs = conn
                    .createStatement()
                    .executeQuery("select version()");
            if (rs.next()) {
                System.out.println(rs.getString(1));
            }
        } catch (Exception e) {
            System.out.println("");
        }
        LocalDateTime ldtFin = LocalDateTime.now();
        Duration duration = Duration.between(ldtInicio, ldtFin);
        System.out.println("Tiempo: " + duration.getSeconds() + " segundos.");
    }
}
