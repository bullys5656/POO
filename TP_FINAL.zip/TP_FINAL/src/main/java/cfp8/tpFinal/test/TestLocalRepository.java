package cfp8.tpFinal.test;

import cfp8.tpFinal.connectors.Connector;
import cfp8.tpFinal.entities.Local;
import cfp8.tpFinal.repositories.jdbc.LocalRepositories;

public class TestLocalRepository {

    public static void main(String[] args) {
        Connector conn = new Connector();
        LocalRepositories lr = new LocalRepositories(conn.getConnection());
        Local local = new Local("Av Corrientes", "MicroCentro", "CABA", 565, 43289584, "", "", "MicroCentro");
        lr.save(local);
        System.out.println("***********************- Muestar todos los locales -****************************");
        lr.getAll().forEach(System.out::println);
        local = lr.getById(1);
        local.setComentarios("Local cerrado");
        lr.update(local);
        lr.getAll().forEach(System.out::println);
        lr.remove(local);
        lr.getAll().forEach(System.out::println);

    }

}
