package cfp8.tpFinal.test;

import cfp8.tpFinal.repositories.interfaces.I_ClienteRepository;
import cfp8.tpFinal.connectors.Connector;
import cfp8.tpFinal.entities.Cliente;
import cfp8.tpFinal.entities.Equipo;
import cfp8.tpFinal.entities.Local;
import cfp8.tpFinal.enums.TipoEquipo;
import cfp8.tpFinal.repositories.jdbc.ClienteRepositories;
import cfp8.tpFinal.repositories.jdbc.EquipoRepositories;
import cfp8.tpFinal.repositories.jdbc.LocalRepositories;

public class TestRepository {

    public static void main(String[] args) {

//             I_ClienteRepository cr=new I_ClienteRepository(new Connector().getConnection());
//        Cliente cliente= new Cliente("Diego", "Toscano", "eltosca@hotmail.com", "Corrientes", 48, "");
//        cr.save(cliente);
//        System.out.println(cliente);
//         System.out.println("***************************************************");
//         
        Connector conn = new Connector();
        ClienteRepositories cr = new ClienteRepositories(conn.getConnection());
        Cliente cliente = new Cliente("Diego", "Toscano", "Corrientes 48", "eltosca@hotmail.com", 48488, "");
        //Alta cliente
        cr.save(cliente);
        System.out.println(cliente);
        System.out.println("***************************************************");
        cliente = cr.getById(1);
        cliente.setNombre("Pepito");
        cliente.setApellido("Toscanossss");
        // Modifica Cliente
        cr.update(cliente);

        // Muestra todos los clientes
        cr.getAll().forEach(System.out::println);
        System.out.println("***************************************************");
        // Busca nombre
        cr.getLikeNombre("Pepito").forEach(System.out::println);
        System.out.println("*******************- Muestra por apellido -********************************");
        // Busca apellido
        cr.getLikeApellido("Toscanossss").forEach(System.out::println);

        EquipoRepositories er = new EquipoRepositories(conn.getConnection());

        Equipo equipo = new Equipo("Sony", "Con pantallita", "YYYxxx", TipoEquipo.CELULAR, "Todo rayado");
        // Alta de equipo 
        er.save(equipo);
//        equipo = er.getById(1); 
//        equipo.setMarca("Samsung");
//        // Update equipo
//        er.update(equipo);
        System.out.println("********************- Muestra todos los equipos*******************************");
        // muestra todos los equipos
        er.getAll().forEach(System.out::println);
        System.out.println("********************- Muestra por Marca -*******************************");
        //Mostrar por marca
        er.getMarca("motorola").forEach(System.out::println);
// Mostrar por serie
        System.out.println("***********************- Muestar Por numero de Serie -****************************");
        er.getNserie("xxxYYY").forEach(System.out::println);
        System.out.println("***********************- Muestar Por tipo -****************************");
        er.getTipoEqui("NOTEBOOK").forEach(System.out::println);

    
    }

}
