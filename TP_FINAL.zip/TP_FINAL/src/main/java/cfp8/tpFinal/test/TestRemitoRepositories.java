package cfp8.tpFinal.test;

import cfp8.tpFinal.connectors.Connector;
import cfp8.tpFinal.repositories.jdbc.RemitoRepositories;
import cfp8.tpFinal.entities.Remito;
import cfp8.tpFinal.enums.EstadoRep;

public class TestRemitoRepositories {

    public static void main(String[] args) {
        Connector conn = new Connector();
        RemitoRepositories rr = new RemitoRepositories(conn.getConnection());
        Remito remito = new Remito(EstadoRep.PRESUPUESTAR, "No le arranca", "", 0, "23/11/21", 1, 1, 1, 1);
        rr.save(remito);
        rr.getAll().forEach(System.out::println);
    }
}
