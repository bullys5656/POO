
insert into clientes (nombre,apellido, mail,direccion ,tel,comentarios) values
('Greta','Muller','esgreta@hotmail.com',null,1551081431,null)
,('Andrea','Martino','andre.martinohotmail.com',null,47686917,null)
,('Marina','Smuller','marina.smuller@hotmail.com',null,null,null)
,('Maria Eugenia ','Esperon','esperoma@hotmail.com',null,null,null)
,('Gustavo','Nieves','boladenieve@hotmail.com',null,47290948,null)
,('Matias','DAngelo','dangelom@hotmail.com',null,null,null)
,('Matias','Lopez','matilopez@hotmail.com',null,null,null)
,('Leonardo','Heine','ladrondetucerebro@hotmail.com',null,43289548,null)
,('Fernanda','Pfuor','laolvidada@hotmail.com','Villaroel 3535',null,null)
;

insert into usuarios (nombre, apellido) values ('Alejandro','Krull')
,('Juan Pablo', 'Bras')
,('Tomas', 'Trasso')
,('Jose', 'Salinas')
,('Oscar','DelaBorda');
select * from equipos;

insert into equipos (tipo,marca,n_serie) values
('1','MOTOROLA',1123456)
,('1','MOTOROLA',1123456)
,('CELULAR','iphone',85452)
,('TABLETA','Apple',123456)
,('1','SAMSUNG',123458156)
,('4','SONY',44123456)
;

insert into repuestos (tipo,precio) values ('PANTALLA',1450)
,('Bateria',3000)
,('Flex de carga',700)
,('Pantalla tactil',3000)
,('Boton de encendido',600);

INSERT INTO remitos (id_usuario,id_cliente,id_equipo,id_repuesto,falla) values 
(1,1,1,1,'No anda pantalla')
,(1,2,2,4,'No anda pantalla')
,(1,3,2,2,'Cambio de bateria')
,(1,4,1,1,'No anda pantalla')
,(1,5,1,3,'No anda flex')
,(3,5,2,3,'No anda flex');




