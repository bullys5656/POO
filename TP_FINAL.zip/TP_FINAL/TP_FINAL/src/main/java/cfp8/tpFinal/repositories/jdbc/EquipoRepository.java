package cfp8.tpFinal.repositories.jdbc;

import cfp8.tpFinal.entities.Equipo;
import cfp8.tpFinal.repositories.interfaces.I_EquipoRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import cfp8.tpFinal.enums.TipoEquipo;

public class EquipoRepository implements I_EquipoRepository {

    private Connection conn;

    public EquipoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Equipo equipo) {
        if (equipo == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into equipos (tipo,n_serie,marca,modelo,comentarios ) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, equipo.getTipoEquipo().toString());
            ps.setString(2, equipo.getN_serie());
            ps.setString(3, equipo.getMarca());
            ps.setString(4, equipo.getModelo());
            ps.setString(5, equipo.getComentarios());

            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                equipo.setId(rs.getInt(1));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Equipo equipo) {
        if (equipo == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement("update equipos set tipo=?,  n_serie=?,marca=?, modelo=?, comentarios=? " + "where id=?",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, equipo.getTipoEquipo().toString());
            ps.setString(2, equipo.getN_serie());
            ps.setString(3, equipo.getMarca());
            ps.setString(4, equipo.getModelo());
            ps.setString(5, equipo.getComentarios());
            ps.setInt(6, equipo.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
            //TODO agregar JOP
        }
    }

    @Override
    public List<Equipo> getAll() {
        List<Equipo> lst = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from equipos")) {
            while (rs.next()) {
                lst.add(new Equipo(rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getString("n_serie"),
                        TipoEquipo.valueOf(rs.getString("tipo")),
                        rs.getString("comentarios"))
                );
            }
        } catch (Exception e) {
            System.out.println(e);
            //TODO agregar aviso JOP
        }
        return lst;

    }

}
