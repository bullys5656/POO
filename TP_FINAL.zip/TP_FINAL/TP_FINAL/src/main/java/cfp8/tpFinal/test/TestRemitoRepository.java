package cfp8.tpFinal.test;

import cfp8.tpFinal.connectors.Connector;

import cfp8.tpFinal.entities.Remito;
import cfp8.tpFinal.enums.EstadoRep;
import cfp8.tpFinal.repositories.jdbc.RemitoRepository;

public class TestRemitoRepository {

    public static void main(String[] args) {
        Connector conn = new Connector();
        RemitoRepository rr = new RemitoRepository(conn.getConnection());
        Remito remito = new Remito(EstadoRep.REPARADO, "No anda ", "", 0, "21/11/28", 1, 1, 1, 1);

        rr.save(remito);
        remito = rr.getById(1);
        System.out.println(remito);
//        rr.getAll().forEach(System.out::println);
    }
}
