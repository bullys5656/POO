package cfp8.tpFinal.repositories.interfaces;

import cfp8.tpFinal.entities.Repuesto;
import java.util.List;
import java.util.stream.Collectors;

public interface I_RepuestoRepository {

    public void save(Repuesto repuesto);

    public void update(Repuesto repuesto);

    List<Repuesto> getAll();

    default Repuesto getById(int id) {
        return getAll()
                .stream()
                .filter(c -> c.getId() == id)
                .findFirst()
                .orElse(new Repuesto());
    }

    default List<Repuesto> getMarca(String marca) {
        return getAll().stream().filter(
                mar -> mar.getMarca() != null && mar.getMarca()
                .toLowerCase()
                .contains(marca.toLowerCase()))
                .collect(Collectors.toList());

    }
}
