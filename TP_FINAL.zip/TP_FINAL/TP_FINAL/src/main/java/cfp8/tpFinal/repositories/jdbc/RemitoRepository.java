package cfp8.tpFinal.repositories.jdbc;

import cfp8.tpFinal.entities.Remito;
import cfp8.tpFinal.enums.EstadoRep;
import cfp8.tpFinal.repositories.interfaces.I_Remitorepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class RemitoRepository implements I_Remitorepository {

    private Connection conn;

    public RemitoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Remito remito) {
        if (remito == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into remitos (falla, infotecnico, estado,precio,fecha,id_usuario,id_cliente,id_equipo,id_repuesto) values (?,?,?,?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, remito.getFalla());
            ps.setString(2, remito.getInfoTec());
            ps.setString(3, remito.getEstado().toString());
            ps.setDouble(4, remito.getPrecio());
            ps.setString(5, remito.getFecha());
            ps.setInt(6, remito.getId_usuario());
            ps.setInt(7, remito.getId_cliente());
            ps.setInt(8, remito.getId_equipo());
            ps.setInt(9, remito.getId_repuesto());

            ps.execute();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                remito.setId(rs.getInt(1));
            }

        } catch (Exception e) {
            System.out.println(e);
         
        }
    }

    @Override
    public void update(Remito remito) {
        if (remito == null) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "update remitos set falla=?, infotecnico=?, estado=?, precio=?,fecha=?, id_usuario=?,id_cliente=?,id_equipo=?,id_repuesto=? where id=?"
        )) {
            ps.setString(1, remito.getFalla());
            ps.setString(2, remito.getInfoTec());
            ps.setString(3, remito.getEstado().toString());
            ps.setDouble(4, remito.getPrecio());
            ps.setString(5, remito.getFecha());
            ps.setInt(6, remito.getId_usuario());
            ps.setInt(7, remito.getId_cliente());
            ps.setInt(8, remito.getId_repuesto());
            ps.setInt(9, remito.getId_equipo());
            ps.setInt(10, remito.getId());

            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Remito> getAll() {
        List<Remito> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from remitos")) {
            while (rs.next()) {
                list.add(new Remito(rs.getInt("id"),
                        EstadoRep.valueOf(rs.getString("estado")),
                        rs.getString("falla"), rs.getString("infotecnico"),
                        rs.getDouble("precio"),
                        rs.getString("fecha"),
                        rs.getInt("id_usuario"),
                        rs.getInt("id_cliente"),
                        rs.getInt("id_equipo"),
                        rs.getInt("id_repuesto")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
}
