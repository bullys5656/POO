/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cfp8.tpFinal.test;

import cfp8.tpFinal.connectors.Connector;
import cfp8.tpFinal.entities.Cliente;
import cfp8.tpFinal.repositories.jdbc.ClienteRepository;

/**
 *
 * @author Werner
 */
public class TestClienteRepository {
    
    public static void main(String[] args) {
        //             I_ClienteRepository cr=new I_ClienteRepository(new Connector().getConnection());
//        Cliente cliente= new Cliente("Diego", "Toscano", "eltosca@hotmail.com", "Corrientes", 48, "");
//        cr.save(cliente);
//        System.out.println(cliente);
//         System.out.println("***************************************************");
//         
        Connector conn = new Connector();
        ClienteRepository cr = new ClienteRepository(conn.getConnection());
        Cliente cliente = new Cliente("Diego", "Toscano", "Corrientes 48", "eltosca@hotmail.com", 48488, "");
        //Alta cliente
        cr.save(cliente);
        System.out.println(cliente);
        System.out.println("***************************************************");
        cliente = cr.getById(1);
        cliente.setNombre("Pepito");
        cliente.setApellido("Toscanossss");
        // Modifica Cliente
        cr.update(cliente);

        // Muestra todos los clientes
        cr.getAll().forEach(System.out::println);
        System.out.println("***************************************************");
        // Busca nombre
        cr.getLikeNombre("Pepito").forEach(System.out::println);
        System.out.println("*******************- Muestra por apellido -********************************");
        // Busca apellido
        cr.getLikeApellido("Toscanossss").forEach(System.out::println);
        
        
        
    }
    
}
