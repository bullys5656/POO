package cfp8.tpFinal.test;

import cfp8.tpFinal.connectors.Connector;
import cfp8.tpFinal.entities.Repuesto;
import cfp8.tpFinal.repositories.jdbc.RepuestoRepository;

public class TestRepuestoRepository {

    public static void main(String[] args) {
                Connector conn = new Connector();
 RepuestoRepository rr= new  RepuestoRepository(conn.getConnection());
    Repuesto repuesto = new Repuesto("Bateroa", "", 500.0, "", "Iphone x", "");
    
    rr.save(repuesto);
    rr.getAll().forEach(System.out::println);
  repuesto=rr.getById(1);
  repuesto.setMarca("Generico");
  rr.update(repuesto);
  rr.getAll().forEach(System.out::println);
  
        System.out.println("**************************");
        rr.getMarca("generico").forEach(System.out::println);
    }
    

}
