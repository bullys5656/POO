package cfp8.tpFinal.test;

import cfp8.tpFinal.connectors.Connector;
import cfp8.tpFinal.entities.Usuario;
import cfp8.tpFinal.repositories.jdbc.UsuarioRepository;

public class TestUsuarioRepositories {

    public static void main(String[] args) {

        Connector conn = new Connector();

        UsuarioRepository ur = new UsuarioRepository(conn.getConnection());

        Usuario user = new Usuario("Nicolas", "Rocha", 5250, "Siglo XX2525", "", "");

        ur.save(user);
        user = ur.getById(1);
        user.setMail("rochaN@hotmail.com");
        ur.getAll().forEach(System.out::println);
        ur.remove(user);
        System.out.println("**********************");
        ur.getAll().forEach(System.out::println);

    }

}
