package cfp8.tpFinal.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {

    private String url = "jdbc:mysql://localhost:3306/taller?serverTimezone=UTC";
    private String user = "root";
    private String pass = "";

    public Connector() {
    }

    public Connector(String url, String user, String pass) {
        this.url = url;
        this.user = user;
        this.pass = pass;
    }

    public Connection getConnection() {
        Connection conn = null;
        try {
            //Registrar el Driver JDK 8 o JAVAEE 8 o Jakarta 8
            //Class.forName(driver);
            conn = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            System.out.println(e);
        }
        return conn;
    }
}
