package cfp8.tpFinal.enums;

public enum EstadoRep {

    A_PRESUPUESTAR,
    REPARADO,
    SIN_REPARACION,
    ESPERANDO_CONFIRMACION,
    CONFIRMADO;
    
   
    
    
}
