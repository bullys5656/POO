
package cpf8.curso.java.tp2.entitides;

import java.text.DecimalFormat;


public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        
        
    }

    @Override
    public String toString() {
        return "Marca: " + marca + " // Modelo: " + modelo  ;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    public String getPrecioFormat(){
        DecimalFormat df=new DecimalFormat("###,###.00");
    return df.format(this.precio);}

    @Override
    public int compareTo(Vehiculo t) {
     String thisVehiculo= this.getMarca()+","+this.getModelo()+","+this.getPrecioFormat();
     String paraVehiculo= t.getMarca()+","+t.getModelo()+","+t.getPrecioFormat();
     return thisVehiculo.toLowerCase().compareTo(paraVehiculo.toLowerCase());

    }
    
}
