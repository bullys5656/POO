package cpf8.curso.java.tp2.test;

import cpf8.curso.java.tp2.entitides.Vehiculo;
import java.util.ArrayList;
import java.util.List;
import cpf8.curso.java.tp2.entitides.Auto;
import cpf8.curso.java.tp2.entitides.Moto;
import java.util.Comparator;

public class Test {

    public static void main(String[] args) {
        List<Vehiculo> lista = cargaMuestra();
        System.out.println("\n");
        System.out.println("=============================\n\n");
        precioMaxMinY(lista);
        System.out.println("=============================\n\n");
        ordenadoMaM(lista);
        System.out.println("\n");
        System.out.println("=============================\n\n");
        ordenNatural(lista);
        System.out.println("\n");
    }

    private static void ordenNatural(List<Vehiculo> lista) {
        System.out.println("Vehículos ordenados por orden natural:");
        lista.stream().sorted().forEach(System.out::println);
    }

    private static void ordenadoMaM(List<Vehiculo> lista) {
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        lista.stream().sorted(Comparator.comparing(Vehiculo::getPrecio).reversed()).forEach(a -> System.out.println("" + a.getMarca() + " " + a.getModelo()));
    }

    private static void precioMaxMinY(List<Vehiculo> lista) {
        double precioMax = lista.stream().max(Comparator.comparingDouble(Vehiculo::getPrecio)).get().getPrecio();
        lista.stream().filter(zz -> zz.getPrecio() == precioMax).
                forEach(zz -> System.out.println("Vehículo más caro: " + zz.getMarca() + " " + zz.getModelo()));
        double precioMin = lista.stream().min(Comparator.comparingDouble(Vehiculo::getPrecio)).get().getPrecio();
        lista.stream().filter(mm -> mm.getPrecio() == precioMin).
                forEach(mm -> System.out.println("Vehículo más barato:" + mm.getMarca() + " " + mm.getModelo()));
        lista.stream().filter(a -> a.getMarca().toUpperCase().startsWith("Y")).forEach(aa -> System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: " + aa.getMarca() + " " + aa.getModelo() + " " + aa.getPrecioFormat()));
        System.out.println("\n");
    }

    private static List<Vehiculo> cargaMuestra() {
        List<Vehiculo> lista = new ArrayList();
        lista.add(new Auto("Peugeot", "206", 4, 200000.00));
        lista.add(new Moto("Honda", "Titan", 125, 60000.00));
        lista.add(new Auto("Peugeot", "208", 5, 250000.00));
        lista.add(new Auto("Yamaha", "YBR", 160, 80500.50));
        lista.forEach((t) -> {
            System.out.println(t);
        });
        return lista;
    }

}
